import {$,jQuery} from "jquery";
//import popper from "popper.js";
import bootstrap from "bootstrap";

import Inputmask from "inputmask";
//var Inputmask = require('inputmask');

//jQuery(function() {
//  jQuery("body").css("color", "blue");
//});
